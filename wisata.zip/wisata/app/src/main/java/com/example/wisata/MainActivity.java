package com.example.wisata;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvWisata;
    private ArrayList<Wisata> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvWisata = findViewById(R.id.rv_wisata);
        rvWisata.setHasFixedSize(true);

        list.addAll(WisataData.getListData());
        showRecyclerCardView();
    }

    private void showRecyclerCardView() {
        rvWisata.setLayoutManager(new LinearLayoutManager(this));
        CardViewWisataAdapter cardViewWisataAdapter = new CardViewWisataAdapter(this);
        cardViewWisataAdapter.setListWisata(list);
        rvWisata.setAdapter(cardViewWisataAdapter);
        setActionBarTitle("Wisata kota Balikpapan");
    }

    private void setActionBarTitle(String title){
        getSupportActionBar().setTitle(title);
    }
}
