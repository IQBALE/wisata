package com.example.wisata;

import java.util.ArrayList;

public class WisataData {
    public static String[][] data = new String[][]{
            {"Hutan Bakau", "Hutan Bakau Kota Balikpapan", "http://katalogwisata.com/wp-content/uploads/2016/03/Hutan-Bakau-Margomulyo1_800x539.jpg", "Tempat wisata di Balikpapan yang satu ini memiliki menara intai, yang berguna untuk menyaksikan aneka burung yang tinggal dan hidup di hutan bakau tersebut. Jika Anda ingin menyaksikan hewan bekantan, maka datanglah di saat pagi hari tiba atau saat matahari kembali ke peraduannya."},
            {"Kemala Beach", "Pantai Eksotis para Turis", "http://katalogwisata.com/wp-content/uploads/2016/03/kemala-beach-restaurant-2_800x600.jpg", "Di kawasan pantai ini, terdapat berbagai restoran bagi Anda yang ingin bersantap sembari menikmati keindahan panorama laut. Sajian menu makanan disini cukup variatif, mulai dari masakan berbagai daerah di Indonesia hingga masakan Eropa juga tersedia untuk Anda"},
            {"Tugu Monpera", "Simbol Perjuangan ", "http://katalogwisata.com/wp-content/uploads/2016/03/tugu-monpera_800x267.jpg", "Di lantai bawah monumen ini, terdapat sebuah museum kecil dan di bagian belakangnya ada panggung terbuka. Pada sejumlah acara atau event khusus, sering diadakan pertunjukan-pertunjukan tradisional di tempat wisata Balikpapan "},
            {"Taman Bekapai", "Spot Wisata di malam hari", "http://katalogwisata.com/wp-content/uploads/2016/03/Taman-Bekapai_800x592.jpg", "Inilah taman kota yang terletak di jalan protokol di Balikpapan. Berlokasi di pusat kota, Taman Bekapai adalah ruang terbuka publik yang menjadi tempat bersantai di tengah kehidupan kota Balikpapan."},
            {"Hutan Lindung", "Cagar Alam kota Balikpapan", "http://katalogwisata.com/wp-content/uploads/2016/03/hutan-lindung-sungai-wain_800x600.jpeg", "Inilah hutan tropis yang masih belum dijamah tangan – tangan jahil manusia yang ada di Balikpapan. Dengan luas hutan sebesar 10 ribu Hektar, Hutan Lindung Sungai Wain adalah tempat perlindungan dari sejumlah jenis satwa dan flora langka"},
    };

    public static ArrayList<Wisata> getListData(){
        Wisata wisata = null;
        ArrayList<Wisata> list = new ArrayList<>();
        for (String[] aData : data) {
            wisata = new Wisata();
            wisata.setNama(aData[0]);
            wisata.setDesc(aData[1]);
            wisata.setPhoto(aData[2]);
            wisata.setKet(aData[3]);

            list.add(wisata);
        }

        return list;
    }
}